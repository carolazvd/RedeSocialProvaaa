package com.newtonpaiva.dominio;

public class Bilhete {

}
