package com.newtonpaiva.dominio;


import java.util.LinkedList;
import java.util.List;

public class Passageiro {
        public static void main(String[] args) {
                String Passageiro;

                String email;

                String documento;

                List<Passageiro> passageiros = new LinkedList<>()


        }
}